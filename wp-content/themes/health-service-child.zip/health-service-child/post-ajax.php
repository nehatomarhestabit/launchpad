<?php
/**
 * Template Name: Post Ajax Listing  
 */
 
get_header(); ?>

<div class="sp-100 bg-w">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">           
                <?php
                $args = array(
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => '3',
                    'paged' => 1,
                );
                $blog_posts = new WP_Query( $args );
                ?>

                <?php if ( $blog_posts->have_posts() ) : ?>
                    <div class="blog-posts row">
                        <?php while ( $blog_posts->have_posts() ) : $blog_posts->the_post(); ?>
                            <div class="col-lg-4">                            
                            <?php echo get_the_post_thumbnail( $blog_posts->ID, 'full' ); ?>
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php the_excerpt(); ?>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <div class="loadmore">Load More...</div>
                <?php endif; ?>
                </div>
		
		<?php //get_sidebar(); ?>
		</div>
	</div>
<?php get_footer();
?>